# Flappy Bird — Arcade Remix

Version web préparée pour être hébergée sur un site HTTPS et testée dans Safari sur iPad.

## Fonctionnalités reprises du fichier de référence
- Modes Classique, Personnalisé et Chant.
- Difficultés du mode Classique : facile, normal et difficile.
- Mode Chant avec microphone, niveaux assisté/normal/opéra et commande manuelle sans micro.
- Réglages de vitesse, accélération, écart/densité des tuyaux, obstacles mobiles, physique et événements.
- Records locaux, pause/reprise, tutoriel, sons/musique, plein écran et plusieurs langues.
- Interface tactile et cache hors ligne de base après le premier chargement.

## Tester
Ouvrir `index.html` dans un navigateur compatible peut permettre de tester le jeu, mais le microphone et le service worker nécessitent généralement HTTPS (ou localhost).

## Publier pour obtenir un lien web
Héberger le contenu de ce dossier sur un hébergement statique HTTPS. Le fichier d'entrée doit rester `index.html`, et tous les fichiers du dossier doivent être publiés ensemble.
Une fois hébergé, ouvrir l'adresse HTTPS dans Safari. Pour l'ajouter à l'écran d'accueil de l'iPad : bouton Partager → Ajouter à l'écran d'accueil.

## À savoir
Ce paquet est une version web/PWA ; il ne s'agit pas encore d'une application native iOS. Le microphone du mode Chant dépend des permissions Safari et du contexte HTTPS.
